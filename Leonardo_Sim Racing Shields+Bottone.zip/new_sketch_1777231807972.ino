#include <Joystick.h>
#include <SimRacing.h>
#include <Keyboard.h>
#include <util/atomic.h>

// ── CONFIG ──────────────────────────────────────────────────────────────────
constexpr uint8_t PIN_SWITCH      = A3;   // PF4 su Leonardo/ATmega32U4
constexpr uint8_t PIN_SHIFTER_X   = A0;
constexpr uint8_t PIN_SHIFTER_Y   = A2;
constexpr uint8_t PIN_SHIFTER_REV = 2;
constexpr int     ADC_MAX         = 1023;
constexpr bool    SEND_ANALOG_AXIS = false;
constexpr bool    SEND_REVERSE_RAW = false;

// ── SHIFTER / JOYSTICK ───────────────────────────────────────────────────────
SimRacing::LogitechShifter shifter(PIN_SHIFTER_X, PIN_SHIFTER_Y, PIN_SHIFTER_REV);

constexpr int8_t  GEARS[]     = { 1, 2, 3, 4, 5, 6, -1 };   // int8_t basta
constexpr uint8_t NUM_GEARS   = sizeof(GEARS) / sizeof(GEARS[0]);
constexpr uint8_t NUM_BUTTONS = NUM_GEARS + (SEND_REVERSE_RAW ? 1u : 0u);

Joystick_ Joystick(
    JOYSTICK_DEFAULT_REPORT_ID, JOYSTICK_TYPE_JOYSTICK,
    NUM_BUTTONS, 0,
    SEND_ANALOG_AXIS, SEND_ANALOG_AXIS,
    false,false,false,false,false,false,false,false,false
);

// ── SWITCH ISR ───────────────────────────────────────────────────────────────
// Lettura diretta del registro PIN invece di digitalRead() → ~10x più veloce
// A3 = PF4 su ATmega32U4 (Leonardo / Micro)
#define SW_PRESSED() (!(PINF & _BV(4)))   // LOW attivo con INPUT_PULLUP

volatile uint8_t switchEvent = 0;   // 0=nulla, 1=premuto, 2=rilasciato

ISR(PCINT0_vect) {}   // non usato, solo per documentazione — usiamo INT

void onSwitchChange() {
    // Nessuna chiamata a funzione, nessun branch inutile
    switchEvent = SW_PRESSED() ? 1 : 2;
}

// ── SETUP ────────────────────────────────────────────────────────────────────
void setup() {
    pinMode(PIN_SWITCH, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(PIN_SWITCH), onSwitchChange, CHANGE);

    shifter.begin();
    Joystick.begin(false);

    if constexpr (SEND_ANALOG_AXIS) {
        Joystick.setXAxisRange(0, ADC_MAX);
        Joystick.setYAxisRange(ADC_MAX, 0);
    }
}

// ── HELPERS (force-inline, zero call overhead) ───────────────────────────────
__attribute__((always_inline))
static inline void updateGears() {
    const int8_t gear = shifter.getGear();

    for (uint8_t i = 0; i < NUM_GEARS; ++i) {
        if (gear == GEARS[i]) Joystick.pressButton(i);
        else                  Joystick.releaseButton(i);
    }

    if constexpr (SEND_REVERSE_RAW) {
        shifter.getReverseButton() ? Joystick.pressButton(NUM_GEARS)
                                   : Joystick.releaseButton(NUM_GEARS);
    }

    Joystick.sendState();
}

__attribute__((always_inline))
static inline void updateAxes() {
    if constexpr (SEND_ANALOG_AXIS) {
        Joystick.setXAxis(shifter.getPosition(SimRacing::X, 0, ADC_MAX));
        Joystick.setYAxis(shifter.getPosition(SimRacing::Y, 0, ADC_MAX));
        Joystick.sendState();
    }
}

// ── LOOP ─────────────────────────────────────────────────────────────────────
void loop() {
    // Leggi e azzera atomicamente in un colpo solo
    uint8_t ev;
    ATOMIC_BLOCK(ATOMIC_RESTORESTATE) { ev = switchEvent; switchEvent = 0; }

    if (ev == 1) Keyboard.write('1');
    else if (ev == 2) Keyboard.write('0');

    shifter.update();
    if (shifter.gearChanged()) updateGears();

    updateAxes();   // eliminata dal compilatore se SEND_ANALOG_AXIS=false
}